#!/usr/bin/env node

console.log('这是一个脚手架工程');

console.log(require('..')());
