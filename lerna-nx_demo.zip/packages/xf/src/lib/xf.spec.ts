import { xf } from './xf';

describe('xf', () => {
  it('should work', () => {
    expect(xf()).toEqual('xf');
  });
});
